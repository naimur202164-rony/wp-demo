<?php

$config = [
	'name' => __('Menu 2', 'blocksy'),
	'typography_keys' => ['headerMenuFont', 'headerDropdownFont'],
    'devices' => ['desktop'],
	'selective_refresh' => ['menu'],
	'excluded_from' => ['offcanvas']
];
